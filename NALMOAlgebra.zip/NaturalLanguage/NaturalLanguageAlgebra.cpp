#include "Algebra.h"
#include "NestedList.h"
#include "QueryProcessor.h"
#include "StandardTypes.h"
#include "Stream.h"
#include "FTextAlgebra.h"
#include "Python.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring> 
#include <map>
#include <time.h>
#include <DateTime.h>


using namespace std;

#include "../Spatial/SpatialAlgebra.h"
#include "../Relation-C++/RelationAlgebra.h"
#include "../Temporal/TemporalAlgebra.h"

extern NestedList     *nl;
extern QueryProcessor *qp;
const int size=500;

/****************************************************************

0.Local Type

***************************************************************/

struct MyRecord{
    int temp;
    string sql;
	string filename;
	int yy;
	int mm;
	int dd;
	int h;
	int m;
	int s;
	int read_buf;
	int read_size;
	int write_buf;
	int write_size;
};

class RecordManager{

public:
	string filename;
    string sql;
	string cmp;
	ifstream fin;
	map<int, string> file;
    int temp;
    int key_fid;
	RecordManager(){
        temp = 1;
        key_fid = -2555;
        sql = "NULL";
	}
	~RecordManager(){
		fin.close();
	}


	void init(string fn,string c){
		filename = fn;
		cmp = c;
		fin.open(fn.c_str());
		if (!fin.is_open())
			cout << "file is can't open!" << endl;
		else
			cout << "file is open!" << endl;
	}



	bool open_file(int fid, string s){
		if (s != "proglogt.csv" && s.find(cmp) == -1){
			return false;
		}//filename is not have 'cmp'
		if (fid == -1 || fid >= 200){
			cout << "fid = " << fid << ", not match!" << endl;
			return false;
		}
        if (s == "proglogt.csv"){
            key_fid = fid;
			file.insert(pair<int, string>(fid, s));
			return true;
        }
		string ns = s.substr(cmp.size());
		ns = "~"+ns;
		file.insert(pair<int, string>(fid, ns));
		return true;
	}



	bool close_file(int fid){
        if (fid == key_fid){
            key_fid = -2555;
            sql = "NULL";
        }
		map<int, string >::iterator it;
		it = file.find(fid);
		if (it == file.end()){
			//cout << "we do not find fileID" << fid << endl;
			return false;
		}
		else  file.erase(it);  //delete fid;
		return true;

	}



	bool is_open(int fid){
		map<int, string>::iterator it;
		it = file.find(fid);
		if (it == file.end())
			return false;
		else
			return true;
	}



	string get_file(int fid){
		return file[fid];
	}



	int get_fid(string s){
		int t, i, j;
		string ss;
		t = s.rfind('=');
		for (i = t + 2; i<(s.size()) && s[i] != ' '; i++);
		j = i - t - 2;
		ss = s.substr(t + 2, j);
		return atoi(ss.c_str());
	}

    bool check_sql(string s){
        if(s.find("query")!=-1)return true;
        if(s.find("let")!=-1)return true;
        if(s.find("LET")!=-1)return true;
        if(s.find("QUERY")!=-1)return true;
        if(s.find("restore")!=-1)return true;
        if(s.find("RESTORE")!=-1)return true;
        if(s.find("delete")!=-1)return true;
        if(s.find("DELETE")!=-1)return true;
        if(s.find("create")!=-1)return true;
        if(s.find("CREATE")!=-1)return true;
        return false;
    }


	bool next_record(MyRecord &record){
		int pid;
		string time_buf;
		string s;
		string key;
		string fn;
		int fid;
		int buf, reals;
		while (fin >> pid){
			fin >> time_buf;
			getline(fin, s, '\n');
			int i, j;
			i = s.find('(');
			key = s.substr(1, i - 1);
            record.temp =temp;
            temp++;
			if (key == "open"){
				i = s.find('"');
				j = s.find('"', i + 1);
				fn = s.substr(i + 1, j - i - 1);
				fid = get_fid(s);
				open_file(fid, fn);
			}

			if (key == "read"){
				i = s.find('(');
				j = s.find(',', i);
				string ss = s.substr(i + 1, j - i - 1);
				fid = atoi(ss.c_str());
				if (is_open(fid)){
					j = s.find(')');
					i = s.rfind(' ', j);
					ss = s.substr(i + 1, j - i - 1);
					buf = atoi(ss.c_str());
					reals = get_fid(s);
					time_t timep;
					struct tm *p;
					time(&timep);
					p = localtime(&timep);

					record.yy = 1900 + p->tm_year;
					record.mm = 1 + p->tm_mon;
					record.dd = p->tm_mday;

					sscanf(time_buf.c_str(), "%d:%d:%d", &record.h, &record.m, &record.s);

					record.filename = get_file(fid);
					record.read_buf = buf;
					record.read_size = reals;
					record.write_buf = 0;
					record.write_size = 0;
                    record.sql = sql;
					return true;
				}

			}

			if (key == "write"){
				i = s.find('(');
				j = s.find(',', i);
				string ss = s.substr(i + 1, j - i - 1);
				fid = atoi(ss.c_str());
                if (fid == key_fid){
                    i = s.find("\"");
                    j = s.find("\"",i+1);
                    string sq = s.substr(i + 1, j - i -1);
                    if(check_sql(sq)){
						//cout<<sq<<endl;
                        sql = sq;
					}
                    continue;
                }
				if (is_open(fid)){
					j = s.find(')');
					i = s.rfind(' ', j);
					ss = s.substr(i + 1, j - i - 1);
					buf = atoi(ss.c_str());
					reals = get_fid(s);
					time_t timep;
					struct tm *p;
					time(&timep);
					p = localtime(&timep);

					record.yy = 1900 + p->tm_year;
					record.mm = 1 + p->tm_mon;
					record.dd = p->tm_mday;
					sscanf(time_buf.c_str(), "%d:%d:%d", &record.h, &record.m, &record.s);
				    record.filename = get_file(fid);
					record.read_buf = 0;
					record.read_size = 0;
					record.write_buf = buf;
					record.write_size = reals;
					record.sql = sql;

					return true;

				}

			}

			if (key == "close"){
				i = s.find('(');
				j = s.find(')');
				string ss = s.substr(i + 1, j - i - 1);
				fid = atoi(ss.c_str());
				close_file(fid);
			}
		}
		return false;
	}
};

/****************************************************************

1.operator FileMonitor

***************************************************************/
// Type mapping function for the operators -FileMonitor-
// string x string -> stream(tuple(Id, Datetime, Position))
ListExpr FileMonitorTypeMap(ListExpr args)
{
	//error message;
	string msg = "string expected";

	if (nl->ListLength(args) != 2){
		ErrorReporter::ReportError(msg + " (invalid number of arguments)");
		return nl->TypeError();
	}
	ListExpr filename = nl->First(args);
	ListExpr emp = nl->Second(args);
	if (nl->SymbolValue(filename) != "string" || nl->SymbolValue(emp) != "string"){
		ErrorReporter::ReportError(msg + " (args are not string)");
		return listutils::typeError();
	}
	return nl->TwoElemList(
		nl->SymbolAtom("stream"),
		nl->TwoElemList(
		nl->SymbolAtom("tuple"),
		nl->Cons(
		nl->TwoElemList(
		nl->SymbolAtom("Datetime"),
		nl->SymbolAtom("instant")),
		nl->SixElemList(
		nl->TwoElemList(
		nl->SymbolAtom("Filename"),
		nl->SymbolAtom("string")),
		nl->TwoElemList(
		nl->SymbolAtom("Sql"),
		nl->SymbolAtom("string")),
		nl->TwoElemList(
		nl->SymbolAtom("Readbuf"),
		nl->SymbolAtom("int")),
		nl->TwoElemList(
		nl->SymbolAtom("Readsize"),
		nl->SymbolAtom("int")),
		nl->TwoElemList(
		nl->SymbolAtom("Writebuf"),
		nl->SymbolAtom("int")),
		nl->TwoElemList(
		nl->SymbolAtom("Writesize"),
		nl->SymbolAtom("int"))
		))));
}

// FileMonitor local information

class FileMonitorLocalInfo
{
public:
	RecordManager *rm;
	ListExpr resulttype;
	int t;

	FileMonitorLocalInfo(){
		rm = new RecordManager;
	}
	~FileMonitorLocalInfo(){
		if (rm){
			delete rm;
		}
	}
};

// FileMonitor value map function
int FileMonitorValueMap(Word *args, Word &result, int message, Word &local, Supplier s)
{
	FileMonitorLocalInfo *localinfo;
	Tuple             *tuple = NULL;
	MyRecord	 mr;
	DateTime   *dt;
	CcString     *cstr;

	string fname;

	switch(message)
	{
	    case OPEN:
	    {
	        if(! local.addr){
	            localinfo = (FileMonitorLocalInfo *)local.addr;
	            delete localinfo;
	        }
	        localinfo = new FileMonitorLocalInfo();
	        string fn = ((CcString*)args[0].addr)->GetValue();
		 string c = ((CcString*)args[1].addr)->GetValue();

		 localinfo->rm->init(fn,c);

	        localinfo->resulttype = nl->Second(GetTupleResultType(s));
	        local.setAddr(localinfo);
	        return 0;
	    }
	    case REQUEST:
	    {
		if(NULL == local.addr){
		    return CANCEL;
		}
		localinfo = (FileMonitorLocalInfo *)local.addr;

		if(!localinfo->rm->next_record(mr)){
		    cout<<"Warning: end to read record!"<<endl;
		    return CANCEL;
		}

		tuple = new Tuple(localinfo->resulttype);
		dt = new DateTime(instanttype);
		dt->Set(mr.yy, mr.mm, mr.dd, mr.h, mr.m, mr.s);
		fname = mr.filename;
		cstr = new CcString(true,fname);
		tuple->PutAttribute(0, dt);
		tuple->PutAttribute(1, cstr);
		tuple->PutAttribute(2, new CcString(true,mr.sql));
		tuple->PutAttribute(3, new CcInt(true, mr.read_buf));
		tuple->PutAttribute(4, new CcInt(true, mr.read_size));
		tuple->PutAttribute(5, new CcInt(true, mr.write_buf));
		tuple->PutAttribute(6, new CcInt(true, mr.write_size));
		// tuple->PutAttribute(1, new CcInt(true, mr.read_buf));
		// tuple->PutAttribute(2, new CcInt(true, mr.read_size));
		// tuple->PutAttribute(3, new CcInt(true, mr.write_buf));
		// tuple->PutAttribute(4, new CcInt(true, mr.write_size));

		result.setAddr(tuple);
		return YIELD;
	    }
	    case CLOSE:
	    {
		localinfo = (FileMonitorLocalInfo *)local.addr;
		delete localinfo;
		local.setAddr(Address(0));
		return 0;
	    }
	       return 0;
	}
	return 0;
}

// operator info of FileMonitor
struct FileMonitorInfo : OperatorInfo {
	FileMonitorInfo()
	{
		name = "filemonitor";
		signature = "string x string -> stream(tuple(Datetime, Filename, SQLname, Read_buf , Read_size , Write_buf , Write_size))";
		syntax = "filemonitor ( _ , _ )";
		meaning = "monitor read and write for file";
	}
};

ListExpr NLMOTypeMap( ListExpr args )
{
  string msg = "string expected";

    if( nl->ListLength(args) != 1){
        ErrorReporter::ReportError(msg + " (invalid number of arguments)");//无效的参数目
        return nl->TypeError();
    }
    ListExpr question = nl->First(args);
    if(nl->SymbolValue(question) != "string"){
        ErrorReporter::ReportError(msg + " (first args is not a string)");
        return listutils::typeError();
    }
 // return nl->SymbolAtom(CcString::BasicType());
    return NList(FText::BasicType()).listExpr();
}





int NLMOValueMap(Word *args, Word &result, int message, Word &local, Supplier s)
{
    string nlresult="";
    string str="/home/xieyang/secondo";
    char *c;
    c=(char *)str.c_str();
    char **p;
    p=&c;
   
//    char *b[20];
//    b[20]="";
//    char *c[20];
//    c[20]=((char *)args[0].addr)->GetValue();
//    b[20]=c[20];
//    char **b;
  //  cout<<"chenggong"<<endl;
    //b[10]="";
    char T[500];
    char a[size];
//    string object="Trains";
//    cout<<"Subject:"+object<<endl;
//    cin.get(a,size);
    // string exe = "/home/jianhua/anaconda2/bin/python";
    Py_SetPythonHome("/home/xieyang/anaconda2");
    Py_Initialize();    // 初始化
    // 将Python工作路径切换到待调用模块所在目录，一定要保证路径名的正确性
    string path = "/home/xieyang";
    string chdir_cmd = string("sys.path.append(\"") + path + "\")";
    const char* cstr_cmd = chdir_cmd.c_str();
    PyRun_SimpleString("import sys");
    PyRun_SimpleString(cstr_cmd);
    PySys_SetArgv(1,p);
    PyRun_SimpleString("import spacy");
    PyRun_SimpleString("sys.path.append('/home/xieyang/anaconda2/lib/python2.7/site-packages')");
 
//    PySys_SetArgv(argc,argv);
//    PyRun_SimpleString("import sys");
//    PyRun_SimpleString("sys.path.append('/home/jianhua/testtry')");
//    PyRun_SimpleString("import spacyutil as su");

    // 加载模块
//    PyObject* moduleName = PyString_FromString("spacyutil"); //模块名，不是文件名
//    PyObject* pModule = PyImport_Import(moduleName);
//    if (!pModule) // 加载模块失败
//    {
//        cout << "[ERROR] Python get module failed." << endl;
//        return 0;
//    }
//    cout << "[INFO] Python get module succeed." << endl;
//
//    // 加载函数
//    PyObject* pv = PyObject_GetAttrString(pModule, "spoken_word_to_number");
//    if (!pv || !PyCallable_Check(pv))  // 验证是否加载成功
//    {
//        cout << "[ERROR] Can't find funftion (test_add)" << endl;
//        return 0;
//    }
//    cout << "[INFO] Get function (test_add) succeed." << endl;

//导入第二个模块

    PyObject* moduleName = PyString_FromString("secondosql"); //模块名，不是文件名
    PyObject* pModule = PyImport_Import(moduleName);
    if (!pModule) // 加载模块失败
    {
        cout << "[ERROR] Python get module failed." << endl;
        return 0;
    }
    cout << "[INFO] Python get module succeed." << endl;

    // 加载函数
    PyObject* pv = PyObject_GetAttrString(pModule, "secondo");
    if (!pv || !PyCallable_Check(pv))  // 验证是否加载成功
    {
        cout << "[ERROR] Can't find funftion (secondo)" << endl;
        return 0;
    }
    cout << "[INFO] Get function (secondo) succeed." << endl;

    string nl = ((CcString*)args[0].addr)->GetValue();
    strcpy(a,nl.c_str());
    // 设置参数
    PyObject* argss = PyTuple_New(2);   // 2个参数
//    PyObject* arg1 = PyString_FromString(a);    // 参数一设为4
////    PyObject* arg2 = PyInt_FromLong(3);    // 参数二设为3
//    PyObject* arg2 = PyString_FromString("Trains");
    PyObject* arg1 = Py_BuildValue("s",a);
    PyObject* arg2 = Py_BuildValue("s","Trains");
    PyTuple_SetItem(argss, 0, arg1);
    PyTuple_SetItem(argss, 1, arg2);

    // 调用函数
    PyObject* pRet = PyObject_CallObject(pv, argss);

    // 获取参数
    if (pRet)  // 验证是否调用成功
    {
        string result1 = PyString_AsString(pRet);
        nlresult = result1;
        cout << "result:" << result1;
    }
    else
        {
        cout<<"result fail";
    }

    Py_Finalize();

  //  strcpy(T,nlresult.c_str());

    result = qp->ResultStorage(s);
   // CcString* res[500] ;

    FText* res = (FText*)(result.addr);

    res->Set(true,nlresult);
 //   ((CcString*)result.addr)->Set(true,nlresult);
 //   cout<<"nlresult:"<<nlresult<<endl;
   // cout<<"sizeofnlresult:"<<sizeof(nlresult)<<endl;
   // cout<<"sizeofres:"<<sizeof(res)<<endl;
    
//    cout<<res<<endl;
  //  cout<<*res<<endl;
  //  cout<<"strlennlresult:"<<strlen(nlresult.c_str())<<endl;
    return 0;

}
struct NLMOInfo : OperatorInfo {
    NLMOInfo()
    {
        name = "nlmo";
        signature = "";
        syntax = "nlmo( )";
        meaning = "Natural language to structured language";
    }
};


/****************************************************************

Algebra Monitor

***************************************************************/
class NaturalLanguageAlgebra : public Algebra
{
public:
	NaturalLanguageAlgebra() : Algebra()
	{
		AddOperator(FileMonitorInfo(), FileMonitorValueMap, FileMonitorTypeMap);
        AddOperator(NLMOInfo(), NLMOValueMap, NLMOTypeMap);
	}

	~NaturalLanguageAlgebra() {}
};


//
//
extern "C"
Algebra* InitializeNaturalLanguageAlgebra(NestedList *nlRef, QueryProcessor *qpRef)
{
	nl = nlRef;
	qp = qpRef;
	cout << "program is here: InitializeNaturalLanguageAlgebra()~" << endl;
	return (new NaturalLanguageAlgebra());
}
