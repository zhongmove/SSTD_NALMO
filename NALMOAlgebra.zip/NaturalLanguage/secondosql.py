#!/usr/bin/env python
# -*- coding: utf-8 -*-

import spacyutil as su
import sys

def secondo(sentence, obj):

    attribute = []
    with open(r'/home/xieyang/reference/attribute.txt', 'r') as f1:
         attribute = f1.readlines()
    f1.close()
    for x in range(0,len(attribute)):
        attribute[x] = attribute[x].strip()
        tt = []
        tt = attribute[x].split()
        if tt[1] == 'mpoint':
            tripp = tt[0]
            attribute.pop(x)
        elif tt[0].find('id') != -1 or tt[0].find('Id') != -1 or tt[0].find('ID') != -1:
            ids = tt[0]
            attribute[x] = tt[0]
        else:
            attribute[x] = tt[0]
    #print(attribute)
    
    project = 'project['
    for y in range(0,len(attribute)):
        project = project + attribute[y] + ', '

    sql_secondo = ""
    commonpart1 = "query "
    commonpart2 = " feed "
    #火车id
    #idcond1 = "filter [.Id="
    idcond1 = "filter [."+ids+"="
    idcond3 = "]"
    #---------------------------------查询地点或轨迹--------------------------------
    
    #查询地点或轨迹语句块
    part3_place = " filter[.Trip present "
    #轨迹查询语句块
    part5_trajectory = "] extend[Stretch: trajectory(.Trip atperiods "
    #part7_trajectory = ")]project[Id, Line, Stretch] consume;"
    part7_trajectory = ")] "+project+"Stretch] consume;"
    #地点查询语句块
    part5_oneplace = "] extend[Pos: val(.Trip atinstant "
    #part7_oneplace = ")] project[Id, Line, Pos] consume;"
    part7_oneplace = ")] "+project+"Pos] consume;"
    #时间段条件
    timescond = ""
    timescond_part1 = "[const periods value ((\"2003-11-20-"
    timescond_part3 = "\" \"2003-11-20-"
    timescond_part5 = "\" TRUE TRUE))]"
    #时间点条件
    timecond = ""
    timecond_part1 = "[const instant value \"2003-11-20-"
    timecond_part3 = "\"]"
    #-----------------------------查询时间或时间段----------------------------------
    #查询时间或时间段
    part3_time = " filter[.Trip passes "
    #时间段语句块
    part5_times = "] extend[Times: deftime(.Trip  at " 
    #part7_times = ")] project[Id, Line, Times]  consume;"
    part7_times = ")] "+project+"Times]  consume;"
    #--------------------------------查询火车--------------------------------------
    part3_train = "filter [(deftime(.Trip  at "
    part5_train = ") intersects "
    part7_train = ")]"
    last = "consume;"
    
    #-------------------------------近邻查询语句块----------------------------------
    sql_secondo1 = sql_secondo2 = ''
    #第一句指令等于first_sql + （var = 't' + id_cond[0]） + first_sql_part1 + id_cond[0] + first_sql_part3
    first_sql = 'let '
    first_sql_part1 = ' = '+obj+' feed filter[.'+ids+' = '
    first_sql_part3 = '] extract[Trip];'
    
    second_sql_part1 = 'query UTOrdered feed '
    second_sql_part3 = ' knearest[UTrip, ' #后加定义的移动点var
    second_sql_part5 = ', '#后加邻居个数
    second_sql_part7 = '] '
    second_sql_part9 = ' consume;'
    #------------------------------时间段过滤器语句块---------------------------------
    time_filter = ''
    time_filter_part1 = 'filter [(deftime(.UTrip) intersects '#后加时间段
    time_filter_part3 = ')] '
    #-------------------------------根据线路近邻查询语句块-----------------------------
    line_filter = ''
    line_filter_part1 = 'filter[.Line ='#后加线路号
    line_filter_part3 = ' ] '
    
    subject = obj
    id_cond = []
    time_cond = []
    place_cond = []
    num_neighbors = ''
    neighbor_query = ''
    line_id = []
    #print("get place function")
    time_cond, neighbor_query, id_cond, place_cond = su.gettime_id_place_others(sentence, obj)
    print(neighbor_query)
    print(time_cond)
    print(id_cond)
    print(place_cond)
    #print(len(time_cond))               
# =============================================================================
#     print(time_cond)
#     print(num_neighbors) 
#     print(id_cond)
#     print(place_cond)
#     print(line_id)       
# =============================================================================
         
    #-------------根据时间或时间段查询地点或轨迹-----------
    print("组装查询语句.......")
    if neighbor_query == '0':
        if id_cond:
            if place_cond:
                if time_cond:
                    if len(time_cond) == 1:
                        print("Standby")
                    if len(time_cond) == 2:
                        print("Standby")
                else:#火车id, 地点  /查时间
                    idcond = idcond1 + id_cond[0] + idcond3
                    sql_secondo = commonpart1 + subject + commonpart2 + idcond + part3_time\
                        + place_cond[0] + part5_times + place_cond[0] + part7_times
            else:
                if time_cond:
                    if len(time_cond) == 1:#火车id，时间 /查地点
                        idcond = idcond1 + id_cond[0] + idcond3
                        timecond = timecond_part1 + time_cond[0] + timecond_part3
                        sql_secondo = commonpart1 + subject + commonpart2  + idcond + part3_place\
                            + timecond + part5_oneplace + timecond + part7_oneplace
                    if len(time_cond) == 2:#火车id，时间段 /查地点
                        idcond = idcond1 + id_cond[0] + idcond3
                        timecond = timescond = timescond_part1 + time_cond[0]\
                            + timescond_part3 + time_cond[1] + timescond_part5
                        sql_secondo = commonpart1 + subject + commonpart2  + idcond + part3_place\
                            + timescond + part5_trajectory + timescond + part7_trajectory
                else:#火车id ,地点 /查时间
                    idcond = idcond1 + id_cond[0] + idcond3
                    sql_secondo = commonpart1 + subject + commonpart2  + idcond + part3_time\
                        + place_cond[0] + part5_times + place_cond[0] + part7_times
        else:
            if place_cond:
                if time_cond:
                    if len(time_cond) == 1:
                        print("Standby")
                    if len(time_cond) == 2:#地点，时间段 /查火车
                        timecond = timescond = timescond_part1 + time_cond[0]\
                            + timescond_part3 + time_cond[1] + timescond_part5
                        sql_secondo = commonpart1 + subject + commonpart2 + part3_train\
                            + place_cond[0] + part5_train + timecond + part7_train + last
                else:#地点 /查时间
                    sql_secondo = commonpart1 + subject + commonpart2 + part3_time + place_cond[0]\
                       + part5_times + place_cond[0] + part7_times
            else:
                if time_cond:
                    if len(time_cond) == 1:#时间 /查地点
                        timecond = timecond_part1 + time_cond[0] + timecond_part3
                        sql_secondo = commonpart1 + subject + commonpart2 + part3_place + timecond\
                            + part5_oneplace + timecond + part7_oneplace
                    if len(time_cond) == 2:#时间段 /查轨迹
                        timecond = timescond = timescond_part1 + time_cond[0]\
                            + timescond_part3 + time_cond[1] + timescond_part5
                        sql_secondo = commonpart1 + subject + commonpart2 + part3_place + timescond\
                            + part5_trajectory + timescond + part7_trajectory
                else:
                    print("nothing")
    else:#近邻查询 
        num_neighbors = neighbor_query
        if time_cond:#根据时间段查
            timecond  = timescond_part1 + time_cond[0] + timescond_part3 + time_cond[1]\
                + timescond_part5
            time_filter = time_filter_part1 + timecond + time_filter_part3
        if line_id:#根据线路查
            line_filter = line_filter_part1 + line_id + line_filter_part3
        var = 't' + id_cond[0]   
        sql_secondo1 = first_sql + var + first_sql_part1 + id_cond[0] + first_sql_part3
        sql_secondo2 = second_sql_part1 + line_filter + time_filter + second_sql_part3 + var + second_sql_part5\
                + num_neighbors +second_sql_part7 + second_sql_part9
    if sql_secondo:
        return sql_secondo
    else:
        return sql_secondo1 + '\n' + sql_secondo2
    
    
#if __name__ == '__main__':
 #   str1 = str(sys.argv[1])
  #  str1 = str1.decode("UTF-8")
   # str2 = str(sys.argv[2])
    #sql = secondo(str1,str2)
   # print(sql)
