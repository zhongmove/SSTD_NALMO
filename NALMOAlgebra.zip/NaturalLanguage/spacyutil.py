# -*- coding: utf-8 -*-
"""
Created on Wed May  1 11:50:30 2019

@author: xixi
"""
import spacy
import re

_known = {
  'zero': 0,
  'one': 1,
  'two': 2,
  'three': 3,
  'four': 4,
  'five': 5,
  'six': 6,
  'seven': 7,
  'eight': 8,
  'nine': 9,
  'ten': 10,
  'eleven': 11,
  'twelve': 12,
  'thirteen': 13,
  'fourteen': 14,
  'fifteen': 15,
  'sixteen': 16,
  'seventeen': 17,
  'eighteen': 18,
  'nineteen': 19,
  'twenty': 20,
  'thirty': 30,
  'forty': 40,
  'fifty': 50,
  'sixty': 60,
  'seventy': 70,
  'eighty': 80,
  'ninety': 90
  }
def spoken_word_to_number(n):#英文数字变为阿拉伯数字
  n = n.lower().strip()
  if n in _known:
    return _known[n]
  else:
    inputWordArr = re.split('[ -]', n)
  assert len(inputWordArr) > 1 #all single words are known
  #Check the pathological case where hundred is at the end or thousand is at end
  if inputWordArr[-1] == 'hundred':
    inputWordArr.append('zero')
    inputWordArr.append('zero')
  if inputWordArr[-1] == 'thousand':
    inputWordArr.append('zero')
    inputWordArr.append('zero')
    inputWordArr.append('zero')
  if inputWordArr[0] == 'hundred':
    inputWordArr.insert(0, 'one')
  if inputWordArr[0] == 'thousand':
    inputWordArr.insert(0, 'one')
  inputWordArr = [word for word in inputWordArr if word not in ['and', 'minus', 'negative']]
  currentPosition = 'unit'
  prevPosition = None
  output = 0
  for word in reversed(inputWordArr):
    if currentPosition == 'unit':
      number = _known[word]
      output += number
      if number > 9:
        currentPosition = 'hundred'
      else:
        currentPosition = 'ten'
    elif currentPosition == 'ten':
      if word != 'hundred':
        number = _known[word]
        if number < 10:
          output += number*10
        else:
          output += number
      #else: nothing special
      currentPosition = 'hundred'
    elif currentPosition == 'hundred':
      if word not in [ 'hundred', 'thousand']:
        number = _known[word]
        output += number*100
        currentPosition = 'thousand'
      elif word == 'thousand':
        currentPosition = 'thousand'
      else:
        currentPosition = 'hundred'
    elif currentPosition == 'thousand':
      assert word != 'hundred'
      if word != 'thousand':
        number = _known[word]
        output += number*1000
    else:
      assert "Can't be here" == None
  return(output)

def gettime_id_place_others(s, obj):#提取时间,id和其他条件
    
    s = s + u'am'
    punctuation = []
    with open(r'/home/xieyang/reference/punctuation.txt', 'r') as f2:
        punctuation = f2.readlines()
    f2.close()
    
    for i in range(0, len(punctuation)):
        punctuation[i] = punctuation[i].strip()
    #print("begin")
    nlp = spacy.load("en_core_web_sm")
    #print("try")
    for ii in range(0,len(punctuation)):
        s = s.replace(punctuation[ii],' ')
    s_place = s
    """
    if s.find(u'f')!=-1:
    s = s.replace(u'f',u'F')
    """
    s = s+'.'
    print(s)
    doc = nlp(s)
    doc_place = nlp(s_place)
    timeconds = []
    id_others = []
    tokenss = []
    for token in doc:
        if not token.is_punct | token.is_space:
            tokenss.append(token.orth_)
    #-------update---525----
    tokens = []
    for i in range(0,len(tokenss)):
        if tokenss[i]==u'between':
            tokenss[i]=u'from'
            for j in range(i,len(tokenss)):
                if tokenss[j]!=u'and':
                    tokens.append(tokenss[j])
            break
        elif tokenss[i]==u'from':
            for j in range(i,len(tokenss)):
                if tokenss[j]!=u'to':
                    tokens.append(tokenss[j])
            break
        else:
            tokens.append(tokenss[i])
    print(tokens)
    ss=' '
    ss=ss.join(tokens)
    #print(ss)
    doc = nlp(ss)
    #-----------------------
        
    for ii in doc.ents:
        if ii.label_ == "TIME" or ii.label_ == "QUANTITY":
            timeconds.append(str(ii))
        elif ii.label_ == "CARDINAL":
            id_others.append(str(ii))
    #时间提取
    d1 = re.compile(r'\d+.\d+')#正则表达式针对00：00这样格式的时间
    d2 = re.compile(r'\d+')#正则表达式针对单个数字格式的时间
    time = []
    if timeconds != 0:
        for j in range(0,len(timeconds)):
            temp = d1.findall(timeconds[j])
            if len(temp) != 0:
                for p in temp:
                    time.append(p)
            else:
                temp1 = d2.findall(timeconds[j])
                if len(temp1) != 0:
                    for q in temp1:
                       if (tokens.index(q)+1) <= len(tokens)-1:
                          if tokens[tokens.index(q)+1] == u'pm':
                                q = str(int(q)+12)
                          time.append(q+':00')
    #print(time)
    #提取地点
    token_place = []
    for token in doc_place:
        if not token.is_punct | token.is_space:
            token_place.append(token.orth_)
    place = []
    with open(r'/home/xieyang/reference/places.txt', 'r') as f1:
        placelist = f1.readlines()
    f1.close()
    for i in range(0, len(placelist)):
        placelist[i] = placelist[i].strip().strip('\n')

    for p in reversed(token_place):
        if p.istitle():
            p = p[0].lower() + p[1:]
        if p in placelist:
            place.append(p)
            break    
    #提取查询近邻数
    num_of_neighbor = 0
    pos_neighbor = s.find("neighbor")
    if pos_neighbor != -1:
        num_of_neighbor = 1
        for i in id_others:
            pos = s.find(i)
            if pos < pos_neighbor:
                if i.isdigit():
                    num_of_neighbor = i
                else:
                    num_of_neighbor = spoken_word_to_number(i)
         
    #提取id
    id = []
    obj = obj.lower().rstrip('s')
    for index, e in enumerate(tokens):
        if e.find(obj) != -1 and tokens[index+1] in id_others:
            id.append(tokens[index+1])

    #提取mpoint
    #mpoints = []
    #mpoint = ''
    #with open(r'/home/xin/Desktop/eclipse-workspace/nl2secondo/src/com/nl2secondo/reference/mpoint.txt', 'r') as f4:
    #	mpoints = f4.readlines()
    #f1.close()
    #for i in range(0, len(mpoints)):
    #	mpoints[i] = mpoints[i].strip().strip('\n')
    #for t in tokens:
    #    if t in mpoints:
    #        mpoint = t
    
    #print("This is the end")
    return time, str(num_of_neighbor), id, place


